package client;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;

public class ContactPanel extends JPanel{
	
	private JTextArea contactTextArea = new JTextArea(20,30);
	
	public ContactPanel(ContactControl ic) {
		
		JPanel contactlistPanel = new JPanel(new BorderLayout(5, 5));
		JLabel contactLabel = new JLabel("Available Games", JLabel.CENTER);
		JPanel joinBuffer = new JPanel();
		JPanel hostBuffer = new JPanel();
		JPanel logoutBuffer = new JPanel();
		contactlistPanel.add(contactLabel, BorderLayout.NORTH);

		contactTextArea.setEditable(false);
		contactlistPanel.add(contactTextArea, BorderLayout.SOUTH);
		
		JButton hostButton = new JButton("Host");
		hostButton.addActionListener(ic);
		hostBuffer.add(hostButton);
		JButton joinButton = new JButton("Join");
		joinButton.addActionListener(ic);
		joinBuffer.add(joinButton);
		JButton logoutButton = new JButton("Logout");
		logoutButton.addActionListener(ic);
		logoutBuffer.add(logoutButton);
		JPanel buttonPanel = new JPanel(new BorderLayout(5,5));
		buttonPanel.add(hostButton,BorderLayout.WEST);
		buttonPanel.add(joinBuffer,BorderLayout.CENTER);
		buttonPanel.add(logoutButton,BorderLayout.EAST);
				
		
	    JPanel contactsPanel = new JPanel(new BorderLayout(5,5));
	    contactsPanel.add(contactlistPanel,BorderLayout.NORTH);
	    contactsPanel.add(buttonPanel,BorderLayout.SOUTH);
	    this.add(contactsPanel);
	}

 }
