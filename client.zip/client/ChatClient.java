package client;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import ocsf.client.AbstractClient;

public class ChatClient extends AbstractClient
{
	private String returner;
	
	public ChatClient()
	  {
	    super("localhost",8300);
	  }

	  @Override
	  public void handleMessageFromServer(Object arg0)
	  {
	    System.out.println("Server Message sent to Client " + (String)arg0);
	    if(arg0 instanceof String)
	    {
	    	returner = (String) arg0;
	    }

	    else if(arg0 instanceof ArrayList<?>) {
	    	//This needs to update lobby list on gui with new arraylist
	    	Fix me
	    }
	  }
	  
	  public void connectionException (Throwable exception) 
	  {
		  System.out.println("Connection Exception Occured");
		    System.out.println(exception);
		    System.out.print(exception.getStackTrace());
	  }
	  public void connectionEstablished()
	  {
	    System.out.println("Connected to Server");
	  }
	  
	  public String getString()
	  {
		  return returner;
	  }
}