package client;

import java.awt.CardLayout;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class GameClassController implements ActionListener {

	private JPanel container;
	private JButton[][] tile;
	private String token = "blue_back";
	private JPanel grid;

	public GameClassController(JPanel container)
	{
		this.container = container;
	}

	public void actionPerformed(ActionEvent e)
	{
		String command = e.getActionCommand();
		JButton btn2 = (JButton) e.getSource();


		if(command == "Logout")
		{
			CardLayout cardLayout = (CardLayout)container.getLayout();
			cardLayout.show(container, "1");
		}
		
		else if(command == btn2.getActionCommand())
		{
			
			try {
				Image ig = getScaledImage("client/images/blue_back.png",60,80);
				ImageIcon image = new ImageIcon(ig);
				btn2.setIcon(image);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			


		}

	}

	public Image getScaledImage(String src, int w, int h) throws IOException {

		Image srcImg = ImageIO.read(new File(src));
		BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = resizedImg.createGraphics();

		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();

		return resizedImg;
	}

}
