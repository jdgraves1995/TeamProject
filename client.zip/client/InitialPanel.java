package client;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.*;

public class InitialPanel extends JPanel
{
	// Constructor for the initial panel.
	public InitialPanel(InitialControl ic)
	{
		// Create the controller.
		//InitialControl controller = new InitialControl(container);

		// Create the information label.
		JLabel label = new JLabel("Sequence", JLabel.CENTER);
		label.setFont(new Font("Serif", Font.PLAIN, 30));

		// Create the login button.
		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(ic);
		JPanel loginButtonBuffer = new JPanel();
		loginButtonBuffer.add(loginButton);
		loginButtonBuffer.setOpaque(false);

		// Create the create account button.
		JButton createButton = new JButton("Create");
		createButton.addActionListener(ic);
		JPanel createButtonBuffer = new JPanel();
		createButtonBuffer.add(createButton);
		createButtonBuffer.setOpaque(false);

		// Arrange the components in a grid.
		JPanel grid = new JPanel(new GridLayout(2, 1, 5, 5));
		JPanel bottomGrid = new JPanel(new BorderLayout(5,5));


		bottomGrid.add(loginButtonBuffer, BorderLayout.WEST);
		bottomGrid.add(createButtonBuffer, BorderLayout.EAST);
		label.setOpaque(false);
		bottomGrid.setOpaque(false);
		grid.add(label);
		grid.add(bottomGrid);

		grid.setOpaque(false);
		this.add(grid);
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		BufferedImage bgImage = null;
		try {
			bgImage = ImageIO.read(new File("client/sequenceInitital.jpg"));
	        g.drawImage(bgImage, 0, 0, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
