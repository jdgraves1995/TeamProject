package client;

import java.io.Serializable;

public class CreateAccountData implements Serializable {
	  private String username;
	  private String password;
	  private String verify;
	  
	  // Getters for the username and password.
	  public String getUsername()
	  {
	    return username;
	  }
	  public String getPassword()
	  {
	    return password;
	  }
	  
	  public String getVerify()
	  {
		  return verify;
	  }
	  
	  // Setters for the username and password.
	  public void setUsername(String username)
	  {
	    this.username = username;
	  }
	  public void setPassword(String password)
	  {
	    this.password = password;
	  }
	  
	  public void setVerify(String verify)
	  {
		  this.verify = verify;
	  }
	  
	  // Constructor that initializes the username and password.
	  public CreateAccountData(String username, String password, String verify)
	  {
	    setUsername(username);
	    setPassword(password);
	    setVerify(verify);
	  }
}
