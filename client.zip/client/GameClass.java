package client;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class GameClass extends JPanel
{
	static private String[][] gameBoard = {
			{"fe", "TC", "9C","8C","7C","7H","8H","9H","TH","fe"},
			{"TD","KD","6C","5C","4C","4H","5H","6H","KS","TS"},
			{"9D","6D","QD","3C","2C","2H","3H","QS","6S","9S"},
			{"8D","5D","3D","QC","AC","AH","QH","3S","5S","8S"},
			{"7D","4D","2D","AS","KC","KH","AS","2S","4S","7S"},
			{"7Sa","4Sa","2Sa","ADa","KHa","KCa","ADa","2Da","4Da","7Da"},
			{"8Sa","5Sa","3Sa","QHa","AHa","ACa","QCa","3Da","5Da","8Da"},
			{"9Sa","6Sa","QSa","3Ha","2Ha","2Ca","3Ca","QDa","6Da","9Da"},
			{"TSa","KSa","6Ha","5Ha","4Ha","4Ca","5Ca","6Ca","KDa","TDa"},
			{"fe","THa","9Ha","8Ha","7Ha","7Ca","8Ca","9Ca","TCa","fe"}
	};
	
	


	private JButton[][] buttons = new JButton[gameBoard.length][gameBoard[0].length];
	private JPanel grid;
	
	public GameClass(GameClassController gc) throws IOException
	{
		JButton logout = new JButton("Logout");
		logout.addActionListener(gc);
		
		//Should hold the board, and the buttons on top of the board
		this.setLayout(new BorderLayout(10,10));
		grid = new JPanel(new GridLayout(10,10));
		
		for(int i = 0; i < gameBoard.length; i++)
		{
			for(int j = 0; j < gameBoard[0].length; j++)
			{
				
				String type = gameBoard[i][j];
				buttons[i][j] = new SequenceTile(type);
				buttons[i][j].setContentAreaFilled(false);
				buttons[i][j].addActionListener(gc);
				buttons[i][j].setActionCommand(gameBoard[i][j]);
				grid.add(buttons[i][j]);
			}
		}
		
		this.add(grid, BorderLayout.CENTER);
		this.add(logout, BorderLayout.SOUTH);
			
		}
		

		//This is adding the board image to the center of gameBoar
	
	public JButton[][] getButton()
	{
		return buttons;
	}
	
	public JPanel getPanel()
	{
		return grid;
	}
	
//	@Override
//	protected void paintComponent(Graphics g) {
//		super.paintComponent(g);
//		BufferedImage bgImage = null;
//		try {
//			bgImage = ImageIO.read(new File("client/SequenceBoard.jpg"));
//	        g.drawImage(bgImage, 0, 0, null);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}


}
