package client;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.IOException;

import javax.swing.JPanel;

public class CreateAccountControl implements ActionListener 
{
	private JPanel container;
	private ChatClient client;



	// Constructor for the login controller.
	public CreateAccountControl(JPanel container, ChatClient client)
	{
		this.container = container;
		this.client = client;

	}

	// Handle button clicks.
	public void actionPerformed(ActionEvent ae)
	{
		// Get the name of the button clicked.
		String command = ae.getActionCommand();

		// The Cancel button takes the user back to the initial panel.
		if (command == "Cancel")
		{
			CardLayout cardLayout = (CardLayout)container.getLayout();
			cardLayout.show(container, "1");
		}

		// The Submit button submits the login information to the server.
		else if (command == "Submit")
		{
			// Get the username and password the user entered.
			CreateAccountPanel createPanel = (CreateAccountPanel)container.getComponent(2);
			CreateAccountData data = new CreateAccountData(createPanel.getUsername(), createPanel.getPassword(), createPanel.getVerify());


			// Check the validity of the information locally first.
			if (data.getUsername().equals("") || data.getPassword().equals(""))
			{
				displayError("You must enter a username and password.");
				return;
			}
			else if(!data.getPassword().equals(data.getVerify()))
			{
				displayError("Verify Password must match Password.");
				return;
			}
			else if(data.getPassword().length() < 6){
				displayError("Password has to be at least 6 characters!");
				return;
			}

			try {
				client.sendToServer(data);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(client.getString().equals("CreateAccountSuccess"))
			{
				loginSuccess();
			}
			else {
				displayError("Account already Exist");
			}
		}
	}

	// After the login is successful, set the User object and display the contacts screen. - this method would be invoked by 
	//the ChatClient
	public void loginSuccess()
	{
		System.out.println("Login Succesful \n");
		CardLayout cardLayout = (CardLayout)container.getLayout();
		cardLayout.show(container, "1");
	}

	// Method that displays a message in the error - could be invoked by ChatClient or by this class (see above)
	public void displayError(String error)
	{
		CreateAccountPanel createPanel = (CreateAccountPanel)container.getComponent(2);
		createPanel.setError(error);

	}
}
