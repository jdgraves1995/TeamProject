package client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;

public class ContactControl implements ActionListener {
	private JPanel container;
	private ChatClient client;

	public ContactControl(JPanel container, ChatClient client)
	{
		this.container = container;
		this.client = client;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		
		String command = ae.getActionCommand();
		
		if(command == "Logout")
		{
			CardLayout cardLayout = (CardLayout)container.getLayout();
			cardLayout.show(container, "1");
		}
		
		else if(command == "Join")
		{
			//JoinGame needs this users username and opponents username
			//Opponents username will be from the highlighted lobby to join
			JoinGame temp = new JoinGame();
			client.sendToServer(temp);
			CardLayout cardLayout = (CardLayout)container.getLayout();
			cardLayout.show(container, "5");
		}
		
		else if(command == "Host")
		{
			//HostGame needs this users username
			HostGame temp1 = new HostGame();
			client.sendToServer(temp1);
			CardLayout cardLayout = (CardLayout)container.getLayout();
			cardLayout.show(container, "5");
		}
		
		
	}
}
